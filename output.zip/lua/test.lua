local si=1
while si<1000000 do
    si = si + 1
end

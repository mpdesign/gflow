# -*- coding: utf-8 -*-
# Filename: common.py

# -----------------------------------
# Revision:     2.0
# Date:         2014-06-21
# Author:       mpdesign
# description:  公共脚本
# -----------------------------------

from core.include import *
from db.cdb import *
from db.mdb import *



